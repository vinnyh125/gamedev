Use the arrow keys to move around.
Move over a companion to collect it.
Each companion costs 5 coins.x
